# Aayush Jaiswal — Final Portfolio

Static GitHub Pages portfolio in Nolan cinematic style.

## Included
- Main portfolio: `index.html`
- Nolan cinematic CSS: `css/style.css`
- Portfolio interactions + local assistant: `js/script.js`
- Exactly 51 verified certificate names and issuers
- Real resume PDF
- Responsive layout
- Relative paths; no build step or backend required

## Deploy
Upload the contents of this folder to the root of:
`aayushjaiswal246-rgb.github.io`

Keep `index.html` at repository root.
