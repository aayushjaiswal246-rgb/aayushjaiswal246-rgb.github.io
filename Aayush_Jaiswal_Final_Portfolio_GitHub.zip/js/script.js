/* Aayush Jaiswal — Portfolio Script
   Scroll reveal + local portfolio assistant. No API/backend required. */

const revealObserver = new IntersectionObserver(
  entries => entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('show'); }),
  { threshold: 0.12 }
);
document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

const knowledge = [
  {keys:['20x','20×','yuri','roas'], ans:'At Yuri Woori, monthly ad spend scaled from ₹50K to ₹10L+ (20×), with 4.2× blended ROAS and ₹42L+ monthly attributed revenue.'},
  {keys:['guardian','mql','b2b','lead'], ans:'For Guardian Assessment, Aayush built a B2B lead-generation engine from zero and reached 120+ qualified MQLs/month at 18% conversion, with organic traffic up 40%.'},
  {keys:['retention','whatsapp','crm','repeat'], ans:'Aayush built a WhatsApp CRM using Interakt. Repeat purchase moved from 18% to 22.5% (+25%).'},
  {keys:['cvr','cro','conversion'], ans:'A full-funnel rebuild improved sitewide CVR from 2.4% to 3.1% (+30%) at zero additional media spend.'},
  {keys:['ai','creative','chatgpt','claude'], ans:'The documented AI creative workflow reached 50+ ad variations/week, cut production time 40%, reduced external creative cost 30% and lifted ad-level CVR 15%.'},
  {keys:['skills','tools'], ans:'Core areas include Meta Ads, Google Ads, SEO, AEO/GEO/SXO, CRO, GA4, GTM, Meta CAPI, Looker Studio, CRM/retention, marketplaces, Claude, ChatGPT and MCP.'},
  {keys:['experience','timeline','years'], ans:'The portfolio documents roughly five years of digital marketing experience across D2C, B2C marketplaces, B2B SaaS and FMCG, plus independent/freelance work.'},
  {keys:['brands','clients'], ans:'The portfolio documents 34+ named brand engagements across 8 industries.'}
];

function portfolioAnswer(q){
  const s = q.toLowerCase();
  let best = null, score = 0;
  for(const item of knowledge){
    const n = item.keys.reduce((a,k)=>a + (s.includes(k.toLowerCase()) ? 1 : 0), 0);
    if(n > score){score=n; best=item;}
  }
  return best ? best.ans : 'I can answer from the portfolio about Aayush’s experience, skills, case studies, metrics, brands and certifications. Try asking about Yuri Woori, Guardian Assessment, CRO, CRM, AI, skills or experience.';
}

function openChat(){
  const el=document.getElementById('chat');
  if(!el) return;
  el.classList.add('open'); el.setAttribute('aria-hidden','false');
  document.getElementById('question')?.focus();
}
function closeChat(){
  const el=document.getElementById('chat');
  if(!el) return;
  el.classList.remove('open'); el.setAttribute('aria-hidden','true');
}
function addMessage(text, cls){
  const box=document.getElementById('messages');
  if(!box) return;
  const d=document.createElement('div'); d.className='msg '+cls; d.textContent=text; box.appendChild(d);
  box.scrollTop=box.scrollHeight;
}
function askPreset(q){
  openChat(); addMessage(q,'user'); addMessage(portfolioAnswer(q),'bot');
}
document.getElementById('chatForm')?.addEventListener('submit', e=>{
  e.preventDefault();
  const input=document.getElementById('question');
  const q=input?.value.trim(); if(!q) return;
  addMessage(q,'user'); addMessage(portfolioAnswer(q),'bot'); input.value=''; input.focus();
});
document.addEventListener('keydown', e=>{if(e.key==='Escape') closeChat();});
